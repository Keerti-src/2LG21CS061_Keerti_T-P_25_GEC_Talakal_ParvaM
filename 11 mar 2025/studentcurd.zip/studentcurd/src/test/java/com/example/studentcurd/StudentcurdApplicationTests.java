package com.example.studentcurd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentcurdApplicationTests {

	@Test
	void contextLoads() {
	}

}
